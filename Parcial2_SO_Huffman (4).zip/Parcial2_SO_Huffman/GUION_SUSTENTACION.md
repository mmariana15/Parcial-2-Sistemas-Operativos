# Guion de demostración — Sustentación Parcial 2 (Alternativa 1)

**Duración estimada:** unos 22 minutos (1 + 3 + 3 + 6 + 4 + 2 + 2 + 1). Si necesitan acortar, aceleren en la edición la corrida de `demo/herramientas.sh` y el benchmark.
**Reparto sugerido:** Mariana (partes 0, 1, 2 y 5, unos 9 min), Isabel (partes 4 y 6, unos 6 min), Sofía (parte 3 y cierre, unos 7 min). Ajústenlo a lo que hizo cada una.

## Mapa de la rúbrica

| Criterio (puntos) | Dónde se demuestra | Evidencia que debe verse en pantalla |
|---|---|---|
| Concurrencia en Huffman (25) | Partes 1 y 2 | Los hilos del pool en `ps`, las fases del conteo y la codificación, el escritor en orden, misma salida con 1 y 4 hilos, benchmark |
| Mecanismos de sincronización (25) | Parte 4 | Código de la cola, la barrera, el escritor, el semáforo y el candado; hilos en estado `S` con 0 % de CPU; ThreadSanitizer, Helgrind y DRD con 0 errores |
| Integración con el editor (20) | Parte 3 | Barra de progreso en vivo, edición durante la compresión, `Ctrl+S` y `a` rechazados, `p` permitido, descompresión encima con recarga |
| Corrección algorítmica (15) | Parte 5 | `md5sum` y `diff -s` idénticos, 135 combinaciones de la suite, comparación con el código del profesor |
| Manejo de errores y recursos (15) | Parte 6 | Archivo corrupto detectado, Valgrind sin fugas, cancelación, salida y `SIGTERM` sin temporales |

---

## Antes de grabar

1. Trabajar en Linux o WSL2 con `gcc` y `valgrind` (`sudo apt install build-essential valgrind`). **Sin valgrind, 9 de las 43 pruebas salen como OMITIDAS**, y son justo las de fugas e interbloqueos.
2. Desde la raíz del proyecto:
   ```bash
   bash demo/preparar_demo.sh      # compila y crea demo/archivos/
   bash PRUEBAS_PARCIAL2.sh        # tarda unos 4 min: córranla ANTES y graben solo el final
   ```
3. Abrir **dos terminales lado a lado**, con letra grande y la terminal A de al menos 120 columnas de ancho (si no, la barra se corta):
   - **Terminal A:** el editor.
   - **Terminal B:** comandos y `bash demo/ver_hilos.sh`.
4. Tener abiertos en VS Code (o el editor que usen): `editor/huffman_concurrente.c`, `editor/huffman_secuencial.c`, `editor/tarea.c` y `editor/editor.c`.
5. Frase para explicar las variables de entorno de la demo (decirla una vez):
   > "Para la demo usamos `EAFIT_HUF_RETARDO_MS`, que agrega una pausa por bloque. Sin ella, 2,6 MB se comprimen en 20 milisegundos y no alcanzaríamos a mostrar nada. Solo se usa para mostrar; el algoritmo es el mismo."

Comando del editor que se usa en toda la parte 3 (terminal A):
```bash
cd demo/archivos
EAFIT_HUF_HILOS=4 EAFIT_HUF_BLOQUE=32768 EAFIT_HUF_RETARDO_MS=400 ../../editor/text_editor demo.txt
```
Con esta configuración, la compresión dura unos 17 segundos (82 bloques, 4 hilos) y la descompresión unos 8. Si necesitan más margen para los pasos 3.9 y 3.10, usen `EAFIT_HUF_RETARDO_MS=600`.

---

## Parte 0 — Presentación (1 min)

**Decir:**
- Nombres, curso y que escogimos la **Alternativa 1: compresor Huffman concurrente integrado al editor del Parcial 1**.
- "El proyecto es el Parcial 1 más el Huffman secuencial que el profesor publicó en el repositorio del curso, más los cambios para hacerlo concurrente e integrarlo al editor sin congelarlo."

**Mostrar:** el árbol de carpetas (`ls editor/ tools/ demo/`).

---

## Parte 1 — Diseño y código base (3 min) · Concurrencia en Huffman

**Mostrar** la Figura 1 del informe (`docs/Informe_Parcial2_SO.docx`, sección "Arquitectura y funcionamiento"), que es el diagrama de hilos: editor → coordinador → cola → pool de trabajadores → escritor.

**Decir:**
1. "El hilo principal es el editor. Cuando el usuario escribe `:z`, se crea un **hilo coordinador**. Este crea un **pool de N hilos trabajadores** y un **hilo escritor**."
2. "El archivo se divide en bloques, y la compresión tiene tres fases: conteo en paralelo, un árbol global y codificación en paralelo. El escritor escribe los bloques en orden."

**Mostrar en el código** (`editor/huffman_secuencial.c`):
- La línea 1: el encabezado dice que es el código del profesor (`SO2026B/concurrencia/Huffman/Huf_secuencial`).
- `contar_frecuencias` (línea 273) y `crear_arbol_huffman` (línea 310).
- El único cambio, en la línea 297 (`CAMBIO PARCIAL 2`): "Antes hacía `exit()` si faltaba memoria. Dentro del editor eso cerraría el programa con hilos vivos y la terminal en modo raw."

**Mostrar en el código** (`editor/huffman_concurrente.c`):
- `tarea_contar` (línea 424):
  - Línea 431: "Cada hilo llama a `contar_frecuencias` del profesor **sobre su bloque**, con un histograma propio y sin bloqueos."
  - Línea 433: "Luego suma una sola vez al total con un mutex. Es el mismo patrón de `trabajador_hilo()` en `HILOS_PROCESOS/main.c` de la clase: mapeo local y reducción en sección crítica."
- `construir_arbol_y_codigos` (línea 170): "El coordinador arma un solo árbol global con `crear_arbol_huffman` y `generar_codigos` del profesor."
- `tarea_codificar` (línea 443): "Cada hilo codifica su bloque con la tabla global, que en esta fase solo se lee."

---

## Parte 2 — Concurrencia en vivo (3 min) · Concurrencia en Huffman

**Terminal B:**
```bash
./tools/huf c demo/archivos/demo.txt /tmp/d.huf -t 4 -b 32768 -v
```
**Decir:** "Se ven las fases: *conteo de frecuencias* hasta el 40 %, *construcción del árbol* y *codificación* hasta el 100 %. Son 82 bloques repartidos entre 4 hilos."

**Hilos reales del pool.** En la terminal A abrir el editor con el comando de arriba y escribir `:` → `z` → Enter. En la terminal B:
```bash
bash demo/ver_hilos.sh
```
**Decir:** "Estos son los hilos del proceso: `huf-coordinador`, cuatro `huf-trabajador` y, en la fase de codificación, `huf-escritor`." Salir con `Ctrl+C`. Dejar el editor abierto o cerrarlo con `:q`.

**El orden de salida no depende de los hilos** (terminal B):
```bash
./tools/huf c demo/archivos/demo.txt /tmp/h1.huf -t 1 -b 32768
./tools/huf c demo/archivos/demo.txt /tmp/h4.huf -t 4 -b 32768
cmp /tmp/h1.huf /tmp/h4.huf && echo "IDENTICOS"
```
**Decir:** "Con 4 hilos los bloques terminan en cualquier orden, pero el escritor los escribe 0, 1, 2… El archivo sale idéntico byte a byte al de 1 hilo."

**Rendimiento:**
```bash
./tools/huf bench demo/archivos/grande.txt
```
**Decir:** "La primera fila es la versión secuencial original del profesor. Debajo está la nuestra con 1, 2, 4… hilos y la aceleración. No llega a N veces porque hay partes secuenciales: el árbol y la escritura en disco."

---

## Parte 3 — Integración con el editor (6 min) · Integración con el editor

Terminal A, en `demo/archivos`:
```bash
cp demo_original.txt demo.txt; rm -f *.huf
EAFIT_HUF_HILOS=4 EAFIT_HUF_BLOQUE=32768 EAFIT_HUF_RETARDO_MS=400 ../../editor/text_editor demo.txt
```
Aparecen la animación y el reporte de carga del Parcial 1; presionar **Enter**.

| Paso | Hacer | Debe verse | Decir |
|---|---|---|---|
| 3.1 | `:` → `z` → Enter | El editor vuelve de inmediato y la barra muestra `[Comprimiendo  15% #---------]`, que avanza sola | "La compresión corre en segundo plano y la barra se actualiza en tiempo real." |
| 3.2 | Escribir `hola` y moverse con las flechas | El texto aparece y la columna cambia | "La interfaz no está congelada: puedo seguir editando." |
| 3.3 | `Ctrl+S` | `Archivo ocupado: se esta comprimiendo en segundo plano (xx%)...` | "La tarea tiene el candado de lectura del archivo; guardar lo modificaría, así que se rechaza sin bloquear el editor." |
| 3.4 | `:` → `p 1` → Enter, luego Enter | `Linea 1: Linea 1: Sistemas Operativos...` | "Leer sí se permite: el candado lectores-escritores deja leer a varios a la vez." |
| 3.5 | `:` → `a "linea nueva"` → Enter, luego Enter | `Archivo ocupado...` | "Las órdenes que modifican el archivo (`a`, `d`, `i`, `x`) se rechazan." |
| 3.6 | `:` → `z` → Enter, luego Enter | `Ya hay una tarea en segundo plano en curso...` | "Solo hay una tarea a la vez." |
| 3.7 | `:` → `t` → Enter | Estado `EN CURSO`, la fase, `x/82 bloques`, el porcentaje y `Candado: lectura` | "Mientras escribíamos la orden, la tarea siguió avanzando." |
| 3.8 | Enter y esperar | `[Compresion OK: demo.txt.huf (59.9%)]` | "Terminó; el hilo principal hizo `pthread_join` del coordinador." |
| 3.9 | `:` → `u demo.txt.huf` → Enter | `[Descomprimiendo xx% ...]` | "Ahora descomprimo **encima del mismo archivo abierto**. La tarea toma el candado de **escritura**." |
| 3.10 | Rápido: `:` → `p 1` → Enter | `Archivo ocupado: se esta descomprimiendo...` | "Ahora ni siquiera se puede leer, porque el archivo se está reemplazando." |
| 3.11 | Enter y esperar | `Archivo recargado desde disco tras la descompresion.` y el texto `hola` desaparece | "El editor recarga el archivo nuevo. La recarga se marca antes de soltar el candado, así un `Ctrl+S` nunca escribe el texto viejo encima." |
| 3.12 | En la terminal B: `md5sum demo/archivos/demo.txt demo/archivos/demo_original.txt` | Los dos md5 iguales | "Comprimimos y descomprimimos encima del archivo abierto, y quedó idéntico al original." |
| 3.13 | `:` → `z copia.huf` → Enter, luego `:` → `c` → Enter, luego Enter | `Cancelacion solicitada` y luego `[Tarea cancelada]` | "Cancelar no mata los hilos: se marca la tarea, se despierta a todos y cada uno sale ordenadamente." |
| 3.14 | `:` → `a "linea despues de cancelar"` → Enter, luego Enter | `Linea anadida correctamente.` | "Al cancelar se suelta el candado y el archivo vuelve a ser editable." |
| 3.15 | `:` → `q` | El editor se cierra | — |

**Terminal B, para cerrar la parte:**
```bash
ls demo/archivos                  # no hay copia.huf ni archivos .tmp: la cancelación borró la salida parcial
```
Antes de seguir con la siguiente parte, restauren el archivo: `cp demo/archivos/demo_original.txt demo/archivos/demo.txt`.

**Mostrar en el código** (`editor/editor.c`):
- `esperar_evento` (línea 274) y el `poll()` de la línea 278: "El editor duerme esperando una tecla **o** un byte del pipe de la tarea. No revisa el progreso en un ciclo."
- En `tarea.c`, `notificar_ui` (línea 76): "Los hilos escriben 1 byte en un pipe que no bloquea; nunca tocan la pantalla."

---

## Parte 4 — Sincronización (4 min) · Mecanismos de sincronización

**Mostrar en el código** (`editor/huffman_concurrente.c`), y decir para qué sirve cada primitiva:

| Línea | Qué es | Decir |
|---|---|---|
| 276 y 288 | `cola_meter` y `cola_sacar` | "Es el productor-consumidor visto en clase: una cola acotada de 64 tareas con un mutex y dos variables de condición." |
| 290 | `while (c->n == 0 ...) pthread_cond_wait` | "Siempre es `while`, no `if`, porque un hilo puede despertar sin que la condición se cumpla." |
| 433 | `pthread_mutex_lock` del conteo | "Es la sección crítica del histograma global: 256 sumas por bloque, no un lock por byte." |
| 739 | `while (p->pendientes > 0) pthread_cond_wait(cond_fase)` | "Es una barrera: el árbol se construye solo cuando todos los bloques se contaron." |
| 555 | Escritor en `pthread_cond_wait(cond_listo)` | "El escritor duerme hasta que el bloque **siguiente** esté listo, aunque otros ya hayan terminado." |
| 607, 637 y 568 | Semáforo `ventana` (`sem_init` en 2N, `sem_wait`, `sem_post`) | "Limita a 2N los bloques en memoria." |

**Argumento de que no hay interbloqueo** (decirlo con calma, es lo que más se evalúa):
> "En nuestra primera versión el coordinador repartía bloques y también los escribía. Si la ventana se llenaba, se dormía en `sem_wait` y nadie podía hacer `sem_post`, porque eso lo hacía él mismo al escribir: un interbloqueo. Por eso separamos el escritor en otro hilo. Ahora, si hay bloques pendientes, el siguiente que espera el escritor ya fue repartido y algún trabajador lo va a terminar; si no hay pendientes, la ventana tiene espacio y el coordinador reparte. Además, todos toman los mutex en el mismo orden y nadie espera algo mientras tiene un mutex de otra parte del programa."

**Candado del archivo** (`editor/tarea.c`):
- Línea 387, `pthread_rwlock_trywrlock`: "El editor solo **intenta** tomar el candado; si falla, rechaza la orden. Nunca se congela."
- Línea 236: "Este es el handshake: el usuario no recupera el control hasta que la tarea ya tiene el candado. Así no alcanza a guardar justo cuando la tarea empieza a leer."

**No hay espera activa.** Terminal A: abrir el editor y comprimir (`:z`). Terminal B: `bash demo/ver_hilos.sh`.
> "Todos los hilos están en estado `S`, es decir, dormidos esperando, y casi todos con 0 % de CPU. Si hubiera espera activa, se verían en `R` con CPU alta."

**Evidencia con herramientas** (terminal B, tarda 1 o 2 minutos; pueden acelerarlo en la edición del video):
```bash
bash demo/herramientas.sh
```
Debe verse:
- `ThreadSanitizer`: "2 hilos / 4 hilos / 8 hilos: 0 condiciones de carrera, archivo identico".
- `Helgrind` y `DRD`: `ERROR SUMMARY: 0 errors`.

**Decir:** "ThreadSanitizer detecta condiciones de carrera. Helgrind y DRD detectan carreras y errores en el orden de los locks, que es lo que causa interbloqueos. Los tres reportan cero. La suite completa también corre el **editor entero** compilado con ThreadSanitizer durante una compresión y una descompresión, con cero reportes."

---

## Parte 5 — Corrección algorítmica (2 min) · Corrección algorítmica

Terminal B:
```bash
./tools/huf c demo/archivos/demo.txt /tmp/d.huf -t 4
./tools/huf d /tmp/d.huf /tmp/d.txt -t 4
md5sum demo/archivos/demo_original.txt /tmp/d.txt
diff -s demo/archivos/demo_original.txt /tmp/d.txt
```
Debe verse: los dos md5 iguales y `Files ... are identical`.

**Mostrar el resultado de `PRUEBAS_PARCIAL2.sh`** (ya corrido antes), sección 2:
- "135 combinaciones idénticas al original: 9 tipos de archivo (vacío, un byte, un solo símbolo, binario aleatorio, texto, base64, múltiplo exacto del bloque…), con 1, 2, 3, 4 y 8 hilos y con 3 tamaños de bloque."
- "La versión del profesor recupera el archivo idéntico, y la nuestra produce **exactamente los mismos bytes de datos** que la suya: es su mismo árbol."
- El final de la suite: `RESUMEN: 43 / 43 pruebas pasaron`.

---

## Parte 6 — Manejo de errores y recursos (2 min) · Manejo de errores y recursos

**Archivo dañado:**
```bash
./tools/huf d demo/archivos/corrupto.huf /tmp/c.txt; echo "codigo de salida: $?"
ls /tmp/c.txt
```
Debe verse `bloque 0 corrupto (CRC32 no coincide)`, código de salida 1 y que `/tmp/c.txt` no existe.

**Decir:** "Cada bloque lleva un CRC32. El hilo que detecta el error avisa a los demás, todos terminan, y como escribimos en un temporal y solo hacemos `rename()` si todo salió bien, nunca queda un archivo a medias."

**Memoria y descriptores:** es la sección 3 de `bash demo/herramientas.sh` (ya corrida en la parte 4).
- `All heap blocks were freed -- no leaks are possible` al comprimir y también en la ruta de error.
- `FILE DESCRIPTORS: 3 open (3 std)`: "Solo quedan abiertos stdin, stdout y stderr."

**Salida durante una tarea y señales.** Terminal A: abrir el editor y `:z`. Terminal B:
```bash
pkill -TERM text_editor
ls demo/archivos                   # sin .huf a medias ni .tmp
```
**Decir:** "Los hilos de la tarea se crean con las señales bloqueadas, así que `SIGTERM` llega solo al hilo principal. El manejador solo escribe un byte en el pipe; el editor cancela la tarea, hace `pthread_join` de todos los hilos, libera la memoria y restaura la terminal."

**Mostrar en el código:** `editor_liberar` en `editor/editor.c`, línea 116 (`tarea_finalizar()`): "Antes de liberar cualquier cosa del editor, se cancela la tarea y se espera a sus hilos. Así ningún hilo usa memoria ya liberada."

---

## Cierre (1 min)

- **Resumen:** "Paralelizamos el Huffman del profesor por bloques, con un pool de hilos y un escritor en orden, sin carreras, interbloqueos ni espera activa, e integrado al editor sin congelarlo."
- **Limitaciones (con honestidad):** se comprime lo guardado en disco y no los cambios sin guardar; solo hay una tarea a la vez; dentro del modo de órdenes la barra no se redibuja.
- **Lo que aprendimos:** "Lo difícil no fue crear hilos, sino decidir quién es dueño de cada dato."

---

## Preguntas probables del profesor

- **¿Qué tomaron del código de clase y qué cambiaron?** El conteo, el árbol, los códigos y la liberación son del Huffman secuencial del profesor; solo cambiamos el `exit()` de `crear_nodo`. Todo lo concurrente es nuestro, y la prueba de "mismos bytes de datos" lo demuestra.
- **¿Por qué un pool y no un hilo por bloque?** Un archivo de 1 GB tendría 1024 hilos. Con N hilos se usan todos los núcleos y se reutilizan buffers.
- **¿Por qué `pread()` y no `lseek()` + `read()`?** El cursor del descriptor es compartido entre hilos; `pread()` lee en una posición dada sin moverlo.
- **¿Qué pasa si el bloque 5 termina antes que el 4?** Queda guardado hasta que el escritor escribe el 4. El semáforo limita cuántos pueden acumularse.
- **¿Por qué `while` alrededor de `pthread_cond_wait`?** Por los despertares espurios y porque otra hebra pudo cambiar la condición antes de volver a tomar el mutex.
- **¿Cómo se entera el editor del progreso sin revisar en un ciclo?** Por un *self-pipe*: los hilos escriben 1 byte y el editor duerme en `poll()` sobre el teclado y el pipe.
- **¿Y si el usuario guarda justo cuando termina la descompresión?** La tarea marca la recarga antes de soltar el candado; quien obtiene el candado recarga primero.
- **¿Por qué la versión con 1 hilo es más rápida que la del profesor?** La del profesor escribe bit a bit con códigos en texto, que es más fácil de entender; nosotras convertimos los códigos a enteros una vez y empaquetamos varios bits por operación.
- **¿Para qué sirve `EAFIT_HUF_RETARDO_MS`?** Solo para la demo y las pruebas: hace que una compresión pequeña dure lo suficiente para interactuar con ella. No cambia el algoritmo.

## Si algo falla mientras graban

- **La barra no se ve:** agranden la terminal a más de 120 columnas.
- **La compresión termina muy rápido:** suban `EAFIT_HUF_RETARDO_MS` a 600.
- **ThreadSanitizer falla con "unexpected memory mapping"** (pasa en algunos WSL): corran `setarch -R bash demo/herramientas.sh`.
- **`valgrind: command not found`:** `sudo apt install valgrind`.
- **El editor quedó raro tras un error:** escriban `reset` y Enter en la terminal.
