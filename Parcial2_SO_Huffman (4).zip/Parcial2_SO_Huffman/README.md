# Editor de Texto en Unix + Compresor Huffman Concurrente
### Sistemas Operativos (SO2026B) — Universidad EAFIT

**Integrantes:** Mariana Montoya Deza · Isabel Parra Sierra · Sofía Rojo Salazar

Este repositorio contiene el **Parcial 1** (editor de texto en C con syscalls
POSIX, integrado al shell del curso con `ed_open`) y su extensión para el
**Parcial 2 — Alternativa 1: Compresor de archivos Huffman concurrente
integrado al editor**.

---

## Parcial 2 en una imagen

```
            HILO PRINCIPAL (UI del editor)
   poll( STDIN , pipe de notificacion )   <-- nunca espera a la compresion
        |  tecla -> editar / ordenes          ^
        |  aviso -> redibujar barra [###---]   | write(pipe, 1 byte)
        v                                      |
   ':z'  -> pthread_create ------------> HILO COORDINADOR (tarea en 2do plano)
                                         toma el candado rwlock del archivo
                                         huf_comprimir():
                                           |  cola acotada (mutex + 2 cond)
                                           v
                              +------ POOL DE TRABAJADORES (N hilos) ------+
                              | Fase 1: conteo de frecuencias por bloque   |
                              |   (histograma LOCAL + suma con mutex)      |
                              |  -- barrera (cond_fase) -> arbol global -- |
                              | Fase 3: codificacion de bloques            |
                              +--------------------+-----------------------+
                                                   | res[i] listo (cond_listo)
                                                   v
                                     HILO ESCRITOR (orden 0,1,2,...)
                                     semaforo 'ventana' = max 2N bloques en RAM
                                     -> archivo.huf.tmpXXXX -> rename() atomico
```

## Qué se tomó del curso (repositorio SO2026B del profesor)

El proyecto es **Parcial 1 + código del profesor + los cambios necesarios para hacerlo concurrente**:

| Del repositorio de clase | Dónde se usa |
|---|---|
| `concurrencia/Huffman/Huf_secuencial` (Huffman secuencial con syscalls) | Copiado en `editor/huffman_secuencial.c/.h`. El módulo concurrente usa sus funciones `contar_frecuencias` (en cada hilo, sobre su bloque), `crear_arbol_huffman`, `generar_codigos` y `liberar_arbol`, sus tipos `NodoHuffman` y `Diccionario`, y su recorrido de decodificación. Único cambio: `crear_nodo` ya no llama a `exit()` si falta memoria (marcado `CAMBIO PARCIAL 2`). |
| `concurrencia/HILOS_PROCESOS/main.c` (`trabajador_hilo`) | Patrón de la fase de conteo: **mapeo local sin bloqueos + reducción en sección crítica con mutex**, y `pthread_join` como barrera. |
| `concurrencia/ConcurrenciaParalelismo/matrix_concurrency.c` | Reparto del trabajo en rangos/bloques entre hilos con `pthread_create`/`pthread_join`. |
| `shell/` y el editor `editorEAFIT` | Igual que en el Parcial 1 (`ed_open`, modo de órdenes). |

Lo que agregamos encima: pool fijo de hilos con cola acotada (mutex + variables de condición), barrera de fase, escritor ordenado, ventana con semáforo, índice por bloque para descomprimir en paralelo, CRC32, y la integración asíncrona con el editor.

Una prueba lo comprueba: con un único bloque, los datos comprimidos por nuestra versión miden **exactamente lo mismo** que los del código del profesor (mismo árbol, mismos códigos); solo cambia la cabecera.

## Qué se agregó en el Parcial 2

| Archivo | Qué hace |
|---|---|
| `editor/huffman_secuencial.c/.h` | **Código del profesor** (Huffman secuencial, repo SO2026B). Árbol, códigos y conteo de frecuencias. |
| `editor/huffman_concurrente.c/.h` | **Núcleo concurrente** sobre el código del profesor. Pool de hilos, cola acotada productor-consumidor, conteo de frecuencias en paralelo con reducción local, árbol de Huffman global, codificación/decodificación paralela por bloques, hilo escritor que ensambla en orden, CRC32 por bloque, cancelación y limpieza. |
| `editor/tarea.c/.h` | **Integración con el editor.** Hilo coordinador en segundo plano, *self-pipe* para avisar a la UI sin espera activa, candado lectores-escritores (`pthread_rwlock`) sobre el archivo abierto, manejo de señales. |
| `editor/editor.c` | El bucle principal espera con `poll()` una tecla **o** un aviso de la tarea; barra de estado con progreso en tiempo real; recarga del archivo; salida ordenada. |
| `editor/ordenes.c` | Órdenes nuevas `z`, `u`, `t`, `c`; las órdenes que leen/escriben el archivo toman el candado (siempre *try-lock*: nunca congelan la UI). |
| `editor/comando.c` | `Ctrl+S` respeta el candado; `Ctrl+Q` cancela y une los hilos antes de salir. |
| `tools/huf_cli.c` | Herramienta `huf` (mismos módulos que el editor) para pruebas de integridad y *benchmark*; `huf sc`/`huf sd` corren la versión secuencial original del profesor para comparar. |
| `PRUEBAS_PARCIAL2.sh` | 43 pruebas automáticas: integridad (cmp/md5), errores, TSan, Helgrind, DRD, Valgrind, integración con el editor por pseudo-terminal. |
| `tests/pty_driver.c` | Driver del parcial 1 ampliado (`SENDCTRL`, `CLEAR`, `NOTEXPECT`, `TIMEOUT`). |

## Órdenes nuevas (modo de órdenes, tecla `:`)

| Orden | Descripción |
|---|---|
| `z [destino]` | Comprime el archivo abierto en segundo plano (por defecto `<archivo>.huf`). Vuelve de inmediato al editor; el progreso se ve en la barra. |
| `u <origen.huf> [destino]` | Descomprime en segundo plano (por defecto, el nombre sin `.huf`). Si el destino es el archivo abierto, al terminar el editor lo recarga. |
| `t` | Estado detallado: fase, bloques, porcentaje, tiempo, candado, resultado. |
| `c` | Cancela la tarea: los hilos terminan ordenadamente y se borra la salida parcial. |

Mientras la tarea usa el archivo abierto:

| Situación | Candado de la tarea | Leer (`p`,`s`,`y`,`m`) | Modificar (`Ctrl+S`,`a`,`d`,`i`,`x`) | Editar en pantalla |
|---|---|---|---|---|
| Comprimiendo el archivo abierto | lectura | ✅ permitido | ❌ rechazado con mensaje | ✅ (en memoria) |
| Descomprimiendo **encima** del archivo abierto | escritura | ❌ rechazado | ❌ rechazado | ✅ (se recarga al final) |
| La tarea usa otros archivos | ninguno | ✅ | ✅ | ✅ |

## Compilar y ejecutar

```bash
make            # editor/text_editor, tools/huf y shell/eafitOS
cd editor && ./text_editor archivo.txt
#   :  z           -> comprime en segundo plano
#   :  t           -> estado
#   :  u archivo.txt.huf copia.txt
```

Variables de entorno opcionales:

| Variable | Efecto |
|---|---|
| `EAFIT_HUF_HILOS=n` | Número de trabajadores (por defecto, uno por núcleo). |
| `EAFIT_HUF_BLOQUE=bytes` | Tamaño de bloque (por defecto 1 MiB). |
| `EAFIT_HUF_RETARDO_MS=ms` | **Solo para demostración/pruebas**: pausa por bloque para que una compresión pequeña dure lo suficiente y se pueda interactuar mientras corre. No altera el algoritmo. |

Demostración recomendada (para que se alcance a ver la barra):
```bash
for i in $(seq 1 30000); do echo "Linea $i: texto de prueba para la sustentacion"; done > demo.txt
EAFIT_HUF_BLOQUE=65536 EAFIT_HUF_RETARDO_MS=150 ./editor/text_editor demo.txt
```

Herramienta de línea de comandos:
```bash
./tools/huf c demo.txt demo.huf -t 4 -v     # comprimir con 4 hilos
./tools/huf d demo.huf copia.txt -v         # descomprimir
md5sum demo.txt copia.txt                   # integridad
./tools/huf bench demo.txt                  # secuencial del profesor vs 1, 2, 4... hilos
./tools/huf sc demo.txt prof.huf            # version secuencial del profesor
```

## Documentación

- `docs/Informe_Parcial2_SO.docx`: informe del parcial 2 (código base del curso, arquitectura, protocolo de concurrencia con la tabla "dato compartido → cómo se protege", pruebas, rendimiento y limitaciones).
- `GUION_SUSTENTACION.md`: guion del video de sustentación.

Sin `valgrind` instalado, `PRUEBAS_PARCIAL2.sh` omite 9 pruebas (Helgrind, DRD y memcheck), las reporta como **OMITIDAS** y termina con error. Instálenlo antes de grabar, porque esas pruebas son la evidencia de 0 fugas y 0 interbloqueos.

## Demostración para el video

```bash
bash demo/preparar_demo.sh     # compila y crea demo/archivos/ (demo.txt, grande.txt, corrupto.huf)
bash demo/ver_hilos.sh         # en otra terminal: hilos del editor en vivo (huf-coordinador, huf-trabajador, huf-escritor)
bash demo/herramientas.sh      # ThreadSanitizer, Helgrind, DRD y Valgrind con resumen
```
El paso a paso está en `GUION_SUSTENTACION.md`.

## Pruebas

```bash
bash PRUEBAS.sh                 # parcial 1: 11/11
bash PRUEBAS_PARCIAL2.sh        # parcial 2: 43/43 (requiere valgrind: sudo apt install valgrind)
bash PRUEBAS_PARCIAL2.sh --bench
```

## Formato `.huf`

```
"EHUF" | version | tam_original (u64) | tam_bloque | n_bloques | frecuencias[256] (u64)
indice[n_bloques] = { tam_original u32, crc32 u32, tam_comprimido u64 }
datos comprimidos de cada bloque, en orden
```
Guardar el tamaño comprimido de cada bloque permite que la **descompresión
también sea paralela** (cada trabajador sabe dónde empieza su bloque), y el
CRC32 por bloque detecta archivos corruptos.

---

## Parcial 1 (resumen)

Editor basado en `editorEAFIT` del profesor, con modo de órdenes (`:`) y los
comandos `o p a d q` (base), `i s` (nivel 2) y `m y x` (nivel 3), usando solo
`open/read/write/lseek/ftruncate/fstat/close`. Integrado al shell con
`ed_open` (fork + execvp + waitpid). Ver `PRUEBAS.sh` y el informe del
parcial 1.

## Uso de Inteligencia Artificial

Se usó IA (Claude) como apoyo para aclarar conceptos de concurrencia, revisar
el diseño del protocolo de sincronización, construir la infraestructura de
pruebas y redactar la documentación. El equipo revisó, discutió y validó cada
parte; el detalle está en el informe (`docs/Informe_Parcial2_SO.docx`).
