/*
 * huf_cli.c - Herramienta de linea de comandos sobre el MISMO modulo
 * editor/huffman_concurrente.c que usa el editor. Sirve para:
 *   - pruebas automaticas de integridad (md5sum / cmp) sin pasar por la UI
 *   - medir el rendimiento con distinto numero de hilos (benchmark)
 *
 * Uso:
 *   huf c <origen> <destino.huf> [-t hilos] [-b tam_bloque] [-v]
 *   huf d <origen.huf> <destino>  [-t hilos] [-v]
 *   huf bench <archivo> [-t hilos_max] [-b tam_bloque]
 *   huf sc <origen> <destino>   (version SECUENCIAL del profesor, para comparar)
 *   huf sd <origen> <destino>
 */
#define _GNU_SOURCE
#include "../editor/huffman_concurrente.h"
#include "../editor/huffman_secuencial.h"   /* codigo del profesor (SO2026B) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

static double ahora(void) {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

/* Callback de progreso: imprime en stderr (solo con -v). */
static void mostrar_progreso(void *ctx) {
    HufProgreso *p = ctx;
    HufFase f; int pct;
    huf_progreso_leer(p, &f, &pct, NULL, NULL);
    fprintf(stderr, "\r  %-24s %3d%%", huf_nombre_fase(f), pct);
    if (f == HUF_FASE_TERMINADA) fprintf(stderr, "\n");
}

/* Compresion con el flujo ORIGINAL del profesor (main.c de Huf_secuencial):
 * leer_archivo -> contar_frecuencias -> crear_arbol_huffman -> generar_codigos
 * -> guardar_comprimido. Un solo hilo; se usa como linea base del benchmark. */
static int secuencial_comprimir(const char *origen, const char *destino) {
    size_t n = 0;
    unsigned char *datos = leer_archivo(origen, &n);
    if (!datos) return -1;
    uint32_t frec[MAX_SIMBOLOS];
    contar_frecuencias(datos, n, frec);
    NodoHuffman *raiz = crear_arbol_huffman(frec);
    Diccionario *d = calloc(1, sizeof(Diccionario));
    if (!d) { liberar_arbol(raiz); free(datos); return -1; }
    generar_codigos(raiz, d);
    int r = guardar_comprimido(destino, datos, n, frec, d);
    liberar_arbol(raiz); free(d); free(datos);
    return r;
}

static void uso(void) {
    fprintf(stderr,
        "Uso:\n"
        "  huf c <origen> <destino.huf> [-t hilos] [-b tam_bloque] [-v]\n"
        "  huf d <origen.huf> <destino> [-t hilos] [-v]\n"
        "  huf bench <archivo> [-t hilos_max] [-b tam_bloque]\n"
        "  huf sc <origen> <destino>  |  huf sd <origen> <destino>   (secuencial del profesor)\n");
}

int main(int argc, char **argv) {
    if (argc < 3) { uso(); return 2; }
    const char *modo = argv[1];
    const char *a = argv[2];
    const char *b = (argc > 3 && argv[3][0] != '-') ? argv[3] : NULL;
    HufOpciones op = {0, 0, 0};
    int verbose = 0;
    for (int i = 3; i < argc; i++) {
        if (!strcmp(argv[i], "-t") && i + 1 < argc) op.hilos = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-b") && i + 1 < argc) op.tam_bloque = (size_t)strtoull(argv[++i], NULL, 10);
        else if (!strcmp(argv[i], "-v")) verbose = 1;
    }

    char err[256] = "";
    HufResultado r;
    HufProgreso prog;

    if (!strcmp(modo, "c") || !strcmp(modo, "d")) {
        if (!b) { uso(); return 2; }
        huf_progreso_init(&prog, verbose ? mostrar_progreso : NULL, &prog);
        double t0 = ahora();
        int rc = (modo[0] == 'c') ? huf_comprimir(a, b, &op, &prog, &r, err, sizeof(err))
                                  : huf_descomprimir(a, b, &op, &prog, &r, err, sizeof(err));
        double t = ahora() - t0;
        huf_progreso_destruir(&prog);
        if (rc != HUF_OK) { fprintf(stderr, "huf: %s\n", err); return 1; }
        printf("%s: %llu -> %llu bytes (%.1f%%), %u bloques, %d hilos, %.3f s\n",
               modo[0] == 'c' ? "comprimido" : "descomprimido",
               (unsigned long long)(modo[0] == 'c' ? r.tam_original : r.tam_comprimido),
               (unsigned long long)(modo[0] == 'c' ? r.tam_comprimido : r.tam_original),
               r.tam_original ? 100.0 * (double)r.tam_comprimido / (double)r.tam_original : 0.0,
               r.bloques, r.hilos, t);
        return 0;
    }

    if (!strcmp(modo, "sc") || !strcmp(modo, "sd")) {
        if (!b) { uso(); return 2; }
        double t0 = ahora();
        int rc = modo[1] == 'c' ? secuencial_comprimir(a, b) : descomprimir_archivo(a, b);
        if (rc != 0) { fprintf(stderr, "huf: fallo la version secuencial\n"); return 1; }
        printf("secuencial (profesor): %.3f s\n", ahora() - t0);
        return 0;
    }

    if (!strcmp(modo, "bench")) {
        int max = op.hilos > 0 ? op.hilos : (int)sysconf(_SC_NPROCESSORS_ONLN);
        char tmp_c[] = "/tmp/huf_benchXXXXXX";
        int fd = mkstemp(tmp_c); if (fd < 0) { perror("mkstemp"); return 1; } close(fd);
        char tmp_d[sizeof(tmp_c) + 4]; snprintf(tmp_d, sizeof(tmp_d), "%s.out", tmp_c);
        char tmp_s[sizeof(tmp_c) + 4]; snprintf(tmp_s, sizeof(tmp_s), "%s.seq", tmp_c);
        char tmp_sd[sizeof(tmp_c) + 4]; snprintf(tmp_sd, sizeof(tmp_sd), "%s.sqd", tmp_c);
        double t0s = ahora();
        int ok_s = secuencial_comprimir(a, tmp_s) == 0;
        double tsc = ahora() - t0s;
        t0s = ahora();
        ok_s = ok_s && descomprimir_archivo(tmp_s, tmp_sd) == 0;
        double tsd = ahora() - t0s;
        printf("version              | compresion (s) | descompresion (s)\n");
        printf("---------------------+----------------+------------------\n");
        if (ok_s) printf("secuencial profesor  | %14.3f | %17.3f\n\n", tsc, tsd);
        unlink(tmp_s); unlink(tmp_sd);
        printf("hilos | compresion (s) | speedup | descompresion (s) | speedup\n");
        printf("------+----------------+---------+-------------------+--------\n");
        double base_c = 0, base_d = 0;
        for (int h = 1; h <= max; h *= 2) {
            HufOpciones o = op; o.hilos = h;
            double t0 = ahora();
            if (huf_comprimir(a, tmp_c, &o, NULL, &r, err, sizeof(err)) != HUF_OK) { fprintf(stderr, "%s\n", err); break; }
            double tc = ahora() - t0;
            t0 = ahora();
            if (huf_descomprimir(tmp_c, tmp_d, &o, NULL, &r, err, sizeof(err)) != HUF_OK) { fprintf(stderr, "%s\n", err); break; }
            double td = ahora() - t0;
            if (h == 1) { base_c = tc; base_d = td; }
            printf("%5d | %14.3f | %6.2fx | %17.3f | %6.2fx\n", h, tc, base_c / tc, td, base_d / td);
            if (h * 2 > max && h != max) h = max / 2;   /* incluir siempre max */
        }
        unlink(tmp_c); unlink(tmp_d);
        return 0;
    }
    uso();
    return 2;
}
