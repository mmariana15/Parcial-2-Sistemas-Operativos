#!/bin/bash
# Prepara todo lo necesario para grabar el video de sustentacion.
# Uso: bash demo/preparar_demo.sh   (desde la carpeta raiz del proyecto)
set -e
if ! command -v valgrind >/dev/null; then
  echo "AVISO: valgrind no esta instalado. Instalelo antes de grabar: sudo apt install valgrind"
fi
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
echo ">>> Compilando (make clean && make)..."
make clean >/dev/null 2>&1 || true
echo exit | make >/dev/null
A="$RAIZ/demo/archivos"
rm -rf "$A"; mkdir -p "$A"
echo ">>> Creando demo.txt (archivo de texto de unos 2 MB)..."
for i in $(seq 1 30000); do
  echo "Linea $i: Sistemas Operativos 2026B - compresion Huffman concurrente con hilos POSIX."
done > "$A/demo.txt"
cp "$A/demo.txt" "$A/demo_original.txt"
echo ">>> Creando grande.txt (unos 65 MB, para el benchmark)..."
for i in $(seq 1 25); do cat "$A/demo.txt"; done > "$A/grande.txt"
echo ">>> Creando corrupto.huf (un .huf con 4 bytes danados a proposito)..."
"$RAIZ/tools/huf" c "$A/demo.txt" "$A/corrupto.huf" -b 65536 >/dev/null
printf '\xff\xff\xff\xff' | dd of="$A/corrupto.huf" bs=1 seek=40000 conv=notrunc 2>/dev/null
ls -lh "$A"
echo
echo "Listo. Para la demo del editor use:"
echo "  cd demo/archivos"
echo "  EAFIT_HUF_HILOS=4 EAFIT_HUF_BLOQUE=32768 EAFIT_HUF_RETARDO_MS=400 ../../editor/text_editor demo.txt"
echo "y en otra terminal:  bash demo/ver_hilos.sh"
