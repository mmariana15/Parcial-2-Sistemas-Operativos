#!/bin/bash
# Muestra en vivo los hilos del editor (ejecutar en OTRA terminal durante la demo).
# Columnas: TID = id del hilo, STAT = estado (S = dormido/bloqueado esperando,
# R = ejecutando), %CPU y el nombre del hilo (huf-coordinador, huf-trabajador,
# huf-escritor). Salir con Ctrl+C.
while true; do
  PID=$(pgrep -n text_editor)
  clear
  if [ -z "$PID" ]; then
    echo "El editor no esta abierto."
  else
    echo "Hilos del proceso text_editor (PID $PID) - $(date +%T)"
    echo "Hilos totales: $(ls /proc/$PID/task | wc -l)"
    echo
    ps -L -o tid,stat,pcpu,comm -p "$PID"
  fi
  sleep 0.5
done
