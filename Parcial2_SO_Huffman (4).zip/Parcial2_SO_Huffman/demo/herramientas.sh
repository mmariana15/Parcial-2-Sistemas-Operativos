#!/bin/bash
# Evidencia de concurrencia y recursos para la sustentacion:
#   1) ThreadSanitizer  -> condiciones de carrera
#   2) Helgrind y DRD   -> carreras y errores de orden de locks (interbloqueos)
#   3) Valgrind memcheck-> fugas de memoria y descriptores abiertos
# Uso: bash demo/herramientas.sh   (desde la raiz; antes: bash demo/preparar_demo.sh)
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
A="$RAIZ/demo/archivos"; T="$(mktemp -d)"
FUENTES="tools/huf_cli.c editor/huffman_secuencial.c editor/huffman_concurrente.c"
# -Wno-unused-result: evita avisos del codigo ORIGINAL del profesor (write sin revisar
# en su version secuencial, que no usa el modo concurrente).
F="-pthread -Wno-unused-result"
head -c 400000 "$A/demo.txt" > "$T/peq.txt"

echo "================ 1. ThreadSanitizer (2, 4 y 8 hilos) ================"
gcc -g -O1 -fsanitize=thread $F -o "$T/huf_tsan" $FUENTES
for h in 2 4 8; do
  "$T/huf_tsan" c "$A/demo.txt" "$T/t.huf" -t $h -b 32768 >/dev/null 2>"$T/tsan.txt"
  "$T/huf_tsan" d "$T/t.huf" "$T/t.txt" -t $h >/dev/null 2>>"$T/tsan.txt"
  if grep -q "ThreadSanitizer" "$T/tsan.txt"; then echo "  $h hilos: REPORTE DE CARRERA"; cat "$T/tsan.txt"
  elif cmp -s "$T/t.txt" "$A/demo.txt"; then echo "  $h hilos: 0 condiciones de carrera, archivo identico"; fi
done

gcc -g -O0 $F -o "$T/huf_g" $FUENTES
echo; echo "================ 2. Helgrind y DRD (Valgrind) ================"
valgrind --tool=helgrind "$T/huf_g" c "$T/peq.txt" "$T/h.huf" -t 4 -b 16384 2>&1 >/dev/null | grep "ERROR SUMMARY" | sed 's/^==[0-9]*==/  Helgrind (comprimir):/'
valgrind --tool=drd "$T/huf_g" d "$T/h.huf" "$T/h.txt" -t 4 2>&1 >/dev/null | grep "ERROR SUMMARY" | sed 's/^==[0-9]*==/  DRD (descomprimir):  /'

echo; echo "================ 3. Valgrind memcheck ================"
valgrind --leak-check=full --show-leak-kinds=all --track-fds=yes "$T/huf_g" c "$T/peq.txt" "$T/m.huf" -t 4 -b 16384 2>"$T/mem.txt" >/dev/null
grep -E "in use at exit|All heap blocks|ERROR SUMMARY|FILE DESCRIPTORS" "$T/mem.txt" | sed 's/^==[0-9]*==/  comprimir:  /'
valgrind --leak-check=full --show-leak-kinds=all "$T/huf_g" d "$A/corrupto.huf" "$T/c.txt" -t 4 2>"$T/mem2.txt" >/dev/null
echo "  (descomprimir un archivo DANADO: los hilos se abortan por error)"
grep -E "in use at exit|All heap blocks|ERROR SUMMARY" "$T/mem2.txt" | sed 's/^==[0-9]*==/  error:      /'
rm -rf "$T"
