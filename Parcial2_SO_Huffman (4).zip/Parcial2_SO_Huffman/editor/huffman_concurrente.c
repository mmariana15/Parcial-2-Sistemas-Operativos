/*
 * huffman_concurrente.c - Compresor/descompresor Huffman concurrente (Parcial 2).
 *
 * BASE DEL CURSO (repositorio SO2026B del profesor):
 *   - concurrencia/Huffman/Huf_secuencial: contar_frecuencias, crear_arbol_huffman,
 *     generar_codigos, liberar_arbol y el recorrido de decodificacion
 *     (copiados en huffman_secuencial.c). Este modulo los PARALELIZA por bloques.
 *   - concurrencia/HILOS_PROCESOS/main.c: patron "mapeo local sin bloqueos +
 *     reduccion con mutex" (fase de conteo) y join como barrera.
 *   - concurrencia/ConcurrenciaParalelismo/matrix_concurrency.c: reparto del
 *     trabajo en rangos/bloques entre hilos con pthread_create/pthread_join.
 *
 * ----------------------------------------------------------------------------
 * PROTOCOLO DE CONCURRENCIA (resumen; detalle en el informe)
 * ----------------------------------------------------------------------------
 * Hilos de una operacion:
 *   - Coordinador : el hilo que llama a huf_comprimir()/huf_descomprimir().
 *                   Reparte tareas, construye el arbol y espera las fases.
 *   - Trabajadores: pool de N hilos. Sacan tareas de la cola acotada.
 *   - Escritor    : unico hilo que escribe datos en el archivo de salida,
 *                   en orden estricto de bloque (0,1,2,...).
 *
 * Datos compartidos y quien los protege:
 *   cola (tareas)          -> cola.m + cond no_vacia / no_llena (productor-consumidor)
 *   frec[] global          -> p->m   (cada trabajador suma su histograma LOCAL)
 *   pendientes (barrera)   -> p->m + cond_fase
 *   res[i].listo / datos   -> p->m + cond_listo (escritor espera el bloque sig.)
 *   abortado / error       -> p->m
 *   ventana de bloques     -> semaforo 'ventana' (limita bloques en memoria)
 *   progreso               -> prog->mutex
 *   arbol / tabla codigos  -> SOLO LECTURA durante las fases paralelas: se
 *                             construye antes de encolar la primera tarea de
 *                             codificacion (el mutex de la cola publica los datos).
 *   hist[i], res[i] (datos)-> cada indice lo escribe UN solo trabajador
 *                             (particion de datos: no requiere lock).
 *
 * Jerarquia de locks (para evitar interbloqueos): prog->mutex puede tomarse
 * ANTES que p->m o cola.m (solo en la cancelacion). Nunca se toman p->m y
 * cola.m al mismo tiempo, y nadie toma prog->mutex teniendo p->m o cola.m.
 * ----------------------------------------------------------------------------
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include "huffman_concurrente.h"
#include "huffman_secuencial.h"   /* codigo base del profesor (SO2026B) */

#include <errno.h>
#include <fcntl.h>
#include <semaphore.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

/* ============================================================================
 * Formato del archivo .huf (todos los enteros en little-endian)
 * ----------------------------------------------------------------------------
 *   0   char[4]  magia "EHUF"
 *   4   u32      version (1)
 *   8   u64      tamano original
 *  16   u32      tamano de bloque
 *  20   u32      numero de bloques (n)
 *  24   u64[256] tabla de frecuencias global (para reconstruir el arbol)
 * 2072  n x { u32 tam_original, u32 crc32, u64 tam_comprimido }   (indice)
 *  ...  datos comprimidos de cada bloque, uno tras otro, en orden
 * ========================================================================== */
#define MAGIA        "EHUF"
#define VERSION      1u
#define TAM_CABECERA (4 + 4 + 8 + 4 + 4 + 256 * 8)
#define TAM_ENTRADA  16
#define MAX_LARGO_CODIGO 56   /* cabe en el acumulador de 64 bits (7 + 56 < 64) */
#define COLA_CAP     64

/* ---------------------------------------------------------------------------
 * Utilidades de E/S (reintentan ante EINTR y escrituras/lecturas parciales)
 * ------------------------------------------------------------------------- */
static int escribir_todo(int fd, const void *buf, size_t len) {
    const unsigned char *p = buf;
    while (len > 0) {
        ssize_t n = write(fd, p, len);
        if (n < 0) { if (errno == EINTR) continue; return -1; }
        p += n; len -= (size_t)n;
    }
    return 0;
}

static int pescribir_todo(int fd, const void *buf, size_t len, off_t off) {
    const unsigned char *p = buf;
    while (len > 0) {
        ssize_t n = pwrite(fd, p, len, off);
        if (n < 0) { if (errno == EINTR) continue; return -1; }
        p += n; len -= (size_t)n; off += n;
    }
    return 0;
}

/* pread() lee en un desplazamiento explicito SIN mover el cursor compartido
 * del descriptor: varios hilos pueden leer el mismo fd a la vez sin carrera
 * (con lseek()+read() dos hilos se pisarian el cursor). */
static int pleer_todo(int fd, void *buf, size_t len, off_t off) {
    unsigned char *p = buf;
    while (len > 0) {
        ssize_t n = pread(fd, p, len, off);
        if (n < 0) { if (errno == EINTR) continue; return -1; }
        if (n == 0) { errno = EIO; return -1; }  /* el archivo se acorto */
        p += n; len -= (size_t)n; off += n;
    }
    return 0;
}

static void put_u32(unsigned char *b, uint32_t v) { for (int i = 0; i < 4; i++) b[i] = (unsigned char)(v >> (8 * i)); }
static void put_u64(unsigned char *b, uint64_t v) { for (int i = 0; i < 8; i++) b[i] = (unsigned char)(v >> (8 * i)); }
static uint32_t get_u32(const unsigned char *b) { uint32_t v = 0; for (int i = 3; i >= 0; i--) v = (v << 8) | b[i]; return v; }
static uint64_t get_u64(const unsigned char *b) { uint64_t v = 0; for (int i = 7; i >= 0; i--) v = (v << 8) | b[i]; return v; }

/* ---------------------------------------------------------------------------
 * CRC32: la tabla se construye UNA vez, aunque varios hilos llamen a la vez
 * (pthread_once garantiza ejecucion unica y visibilidad de la tabla).
 * ------------------------------------------------------------------------- */
static uint32_t tabla_crc[256];
static pthread_once_t crc_once = PTHREAD_ONCE_INIT;

static void crc_iniciar_tabla(void) {
    for (uint32_t i = 0; i < 256; i++) {
        uint32_t c = i;
        for (int k = 0; k < 8; k++) c = (c & 1) ? 0xEDB88320u ^ (c >> 1) : c >> 1;
        tabla_crc[i] = c;
    }
}

uint32_t huf_crc32(uint32_t crc, const unsigned char *buf, size_t len) {
    pthread_once(&crc_once, crc_iniciar_tabla);
    crc = ~crc;
    for (size_t i = 0; i < len; i++) crc = tabla_crc[(crc ^ buf[i]) & 0xFF] ^ (crc >> 8);
    return ~crc;
}

/* ---------------------------------------------------------------------------
 * Arbol de Huffman: se REUTILIZA el codigo del profesor (huffman_secuencial.c,
 * repositorio SO2026B): crear_arbol_huffman() + generar_codigos().
 * Su algoritmo es determinista (la misma tabla de frecuencias produce siempre
 * el mismo arbol), asi el compresor y el descompresor obtienen el MISMO arbol.
 *
 * Su diccionario guarda cada codigo como texto ('0'/'1'), comodo para
 * aprender. Para que cada hilo empaquete bits rapido, el coordinador lo
 * convierte UNA vez a enteros (codigo + largo); es solo una traduccion.
 * ------------------------------------------------------------------------- */
static int convertir_diccionario(const Diccionario *d, uint64_t codigo[256], uint8_t largo[256]) {
    memset(largo, 0, 256);
    for (int s = 0; s < MAX_SIMBOLOS; s++) {
        if (!d->presente[s]) continue;
        int len = d->tabla[s].longitud;
        if (len > MAX_LARGO_CODIGO) return -1;
        uint64_t c = 0;
        for (int k = 0; k < len; k++) c = (c << 1) | (uint64_t)(d->tabla[s].codigo[k] == '1');
        codigo[s] = c;
        largo[s] = (uint8_t)len;
    }
    return 0;
}

/* Construye arbol + tabla de codigos con las funciones del profesor.
 * Sus frecuencias son uint32_t: un simbolo no puede repetirse mas de
 * 4.294.967.295 veces (archivos de hasta ~4 GiB por simbolo). */
static int construir_arbol_y_codigos(const uint64_t frec[256], NodoHuffman **raiz, Diccionario *dicc,
                                     uint64_t codigo[256], uint8_t largo[256], char *err, size_t errlen) {
    uint32_t frec32[MAX_SIMBOLOS];
    int simbolos = 0;
    for (int s = 0; s < MAX_SIMBOLOS; s++) {
        if (frec[s] > UINT32_MAX) { snprintf(err, errlen, "un simbolo supera 2^32 apariciones (archivo demasiado grande)"); return -1; }
        frec32[s] = (uint32_t)frec[s];
        if (frec32[s]) simbolos++;
    }
    *raiz = NULL;
    memset(largo, 0, 256);
    if (simbolos == 0) return 0;                        /* archivo vacio: sin arbol */
    *raiz = crear_arbol_huffman(frec32);                /* PROFESOR */
    if (!*raiz) { snprintf(err, errlen, "sin memoria para el arbol de Huffman"); return -1; }
    generar_codigos(*raiz, dicc);                       /* PROFESOR */
    if (convertir_diccionario(dicc, codigo, largo) < 0) {
        snprintf(err, errlen, "arbol demasiado profundo (codigo > %d bits)", MAX_LARGO_CODIGO);
        return -1;
    }
    return 0;
}

/* ---------------------------------------------------------------------------
 * Progreso (compartido con la interfaz)
 * ------------------------------------------------------------------------- */
void huf_progreso_init(HufProgreso *p, void (*notificar)(void *), void *ctx) {
    memset(p, 0, sizeof(*p));
    pthread_mutex_init(&p->mutex, NULL);
    p->notificar = notificar;
    p->ctx = ctx;
}

void huf_progreso_destruir(HufProgreso *p) { pthread_mutex_destroy(&p->mutex); }

void huf_progreso_leer(HufProgreso *p, HufFase *fase, int *pct, unsigned long *hechos, unsigned long *total) {
    pthread_mutex_lock(&p->mutex);
    if (fase) *fase = p->fase;
    if (pct) *pct = p->porcentaje;
    if (hechos) *hechos = p->bloques_hechos;
    if (total) *total = p->bloques_total;
    pthread_mutex_unlock(&p->mutex);
}

const char *huf_nombre_fase(HufFase f) {
    switch (f) {
        case HUF_FASE_INACTIVA:       return "inactiva";
        case HUF_FASE_PREPARANDO:     return "preparando";
        case HUF_FASE_CONTEO:         return "conteo de frecuencias";
        case HUF_FASE_ARBOL:          return "construccion del arbol";
        case HUF_FASE_CODIFICACION:   return "codificacion";
        case HUF_FASE_DECODIFICACION: return "decodificacion";
        case HUF_FASE_FINALIZANDO:    return "finalizando";
        case HUF_FASE_TERMINADA:      return "terminada";
    }
    return "?";
}

/* Cambia de fase (reinicia el contador de bloques de la fase). */
static void progreso_fase(HufProgreso *p, HufFase fase, unsigned long total, int pct) {
    pthread_mutex_lock(&p->mutex);
    p->fase = fase; p->bloques_hechos = 0; p->bloques_total = total; p->porcentaje = pct;
    pthread_mutex_unlock(&p->mutex);
    if (p->notificar) p->notificar(p->ctx);
}

/* Avanza un bloque en la fase actual; el porcentaje global se mapea al
 * rango [base, base+rango]. Solo notifica si el porcentaje cambio. */
static void progreso_avanzar(HufProgreso *p, int base, int rango) {
    int cambio;
    pthread_mutex_lock(&p->mutex);
    p->bloques_hechos++;
    int pct = p->bloques_total ? base + (int)((unsigned long long)rango * p->bloques_hechos / p->bloques_total) : base;
    if (pct > 99 && p->fase != HUF_FASE_TERMINADA) pct = 99;
    cambio = (pct != p->porcentaje);
    p->porcentaje = pct;
    pthread_mutex_unlock(&p->mutex);
    if (cambio && p->notificar) p->notificar(p->ctx);
}

/* ---------------------------------------------------------------------------
 * Cola acotada de tareas (productor = coordinador, consumidores = pool)
 * ------------------------------------------------------------------------- */
typedef enum { T_CONTAR, T_CODIFICAR, T_DECODIFICAR } TipoTarea;
typedef struct { TipoTarea tipo; uint32_t idx; } Tarea;

typedef struct {
    Tarea items[COLA_CAP];
    int ini, n;
    int cerrada;                 /* no habra mas tareas */
    pthread_mutex_t m;
    pthread_cond_t no_vacia, no_llena;
} Cola;

static void cola_init(Cola *c) {
    c->ini = c->n = 0; c->cerrada = 0;
    pthread_mutex_init(&c->m, NULL);
    pthread_cond_init(&c->no_vacia, NULL);
    pthread_cond_init(&c->no_llena, NULL);
}
static void cola_destruir(Cola *c) {
    pthread_mutex_destroy(&c->m);
    pthread_cond_destroy(&c->no_vacia);
    pthread_cond_destroy(&c->no_llena);
}

/* Bloquea (sin espera activa) mientras la cola este llena. -1 si se cerro. */
static int cola_meter(Cola *c, Tarea t) {
    pthread_mutex_lock(&c->m);
    while (c->n == COLA_CAP && !c->cerrada) pthread_cond_wait(&c->no_llena, &c->m);
    if (c->cerrada) { pthread_mutex_unlock(&c->m); return -1; }
    c->items[(c->ini + c->n) % COLA_CAP] = t;
    c->n++;
    pthread_cond_signal(&c->no_vacia);
    pthread_mutex_unlock(&c->m);
    return 0;
}

/* Bloquea mientras la cola este vacia. -1 si esta cerrada y vacia (fin). */
static int cola_sacar(Cola *c, Tarea *t) {
    pthread_mutex_lock(&c->m);
    while (c->n == 0 && !c->cerrada) pthread_cond_wait(&c->no_vacia, &c->m);
    if (c->n == 0) { pthread_mutex_unlock(&c->m); return -1; }
    *t = c->items[c->ini];
    c->ini = (c->ini + 1) % COLA_CAP;
    c->n--;
    pthread_cond_signal(&c->no_llena);
    pthread_mutex_unlock(&c->m);
    return 0;
}

/* Cierra la cola. Si 'descartar', borra las tareas pendientes (abortar). */
static void cola_cerrar(Cola *c, int descartar) {
    pthread_mutex_lock(&c->m);
    c->cerrada = 1;
    if (descartar) c->n = 0;
    pthread_cond_broadcast(&c->no_vacia);
    pthread_cond_broadcast(&c->no_llena);
    pthread_mutex_unlock(&c->m);
}

/* ---------------------------------------------------------------------------
 * Estado de una operacion (pipeline)
 * ------------------------------------------------------------------------- */
typedef struct {
    unsigned char *datos;   /* resultado del bloque (comprimido o descomprimido) */
    size_t tam;
    uint32_t tam_orig;
    uint32_t crc;
    int listo;              /* protegido por p->m */
} ResBloque;

typedef struct Pipeline {
    /* configuracion (solo lectura una vez arrancan los hilos) */
    int fd_in, fd_out;
    uint64_t tam_original;
    size_t tam_bloque;
    uint32_t n_bloques;
    int n_hilos;
    unsigned retardo_ms;
    off_t inicio_datos;              /* offset del primer bloque de salida */
    HufProgreso *prog;

    Cola cola;
    sem_t ventana;                   /* bloques despachados y aun no escritos */

    pthread_mutex_t m;
    pthread_cond_t cond_fase;        /* barrera de la fase de conteo */
    pthread_cond_t cond_listo;       /* el escritor espera el bloque siguiente */
    uint32_t pendientes;
    int abortado, error;
    char err[256];
    uint64_t frec[256];              /* histograma global */

    uint32_t (*hist)[MAX_SIMBOLOS];  /* histograma local por bloque (tipo del profesor) */
    ResBloque *res;

    NodoHuffman *raiz;               /* arbol del profesor (solo lectura en los hilos) */
    Diccionario *dicc;               /* diccionario del profesor */
    uint64_t codigo[256];
    uint8_t largo[256];

    uint64_t *off_comp;              /* descompresion: offset de cada bloque */
    uint64_t *tam_comp;
    uint64_t bytes_escritos;         /* solo lo toca el escritor */
} Pipeline;

/* Marca la operacion como abortada y despierta a TODOS los hilos que
 * pudieran estar esperando (cola, barrera, escritor y semaforo). */
static void pipeline_abortar(Pipeline *p, int es_error, const char *fmt, ...) {
    pthread_mutex_lock(&p->m);
    if (!p->abortado) {
        p->abortado = 1;
        if (es_error) {
            p->error = 1;
            va_list ap; va_start(ap, fmt);
            vsnprintf(p->err, sizeof(p->err), fmt, ap);
            va_end(ap);
        }
    }
    pthread_cond_broadcast(&p->cond_fase);
    pthread_cond_broadcast(&p->cond_listo);
    pthread_mutex_unlock(&p->m);
    cola_cerrar(&p->cola, 1);
    sem_post(&p->ventana);            /* por si el coordinador espera ventana */
}

static int pipeline_abortado(Pipeline *p) {
    pthread_mutex_lock(&p->m);
    int a = p->abortado;
    pthread_mutex_unlock(&p->m);
    return a;
}

void huf_progreso_cancelar(HufProgreso *prog) {
    pthread_mutex_lock(&prog->mutex);     /* jerarquia: prog->mutex -> p->m / cola.m */
    prog->cancelar = 1;
    if (prog->activo) pipeline_abortar(prog->activo, 0, NULL);
    pthread_mutex_unlock(&prog->mutex);
}

/* Registra el pipeline para que la cancelacion pueda alcanzarlo.
 * Retorna -1 si la cancelacion se pidio antes de empezar. */
static int pipeline_registrar(Pipeline *p) {
    pthread_mutex_lock(&p->prog->mutex);
    int cancelado = p->prog->cancelar;
    if (!cancelado) p->prog->activo = p;
    pthread_mutex_unlock(&p->prog->mutex);
    return cancelado ? -1 : 0;
}
static void pipeline_desregistrar(Pipeline *p) {
    pthread_mutex_lock(&p->prog->mutex);
    p->prog->activo = NULL;
    pthread_mutex_unlock(&p->prog->mutex);
}

static void dormir_ms(unsigned ms) {
    struct timespec ts = { (time_t)(ms / 1000), (long)(ms % 1000) * 1000000L };
    while (nanosleep(&ts, &ts) == -1 && errno == EINTR) {}
}

/* ---------------------------------------------------------------------------
 * Trabajo de cada tipo de tarea
 * ------------------------------------------------------------------------- */
static size_t tam_bloque_i(Pipeline *p, uint32_t i) {
    uint64_t ini = (uint64_t)i * p->tam_bloque;
    uint64_t resto = p->tam_original - ini;
    return resto < p->tam_bloque ? (size_t)resto : p->tam_bloque;
}

/* FASE 1: cuenta frecuencias del bloque en un histograma LOCAL (sin locks),
 * y luego hace UNA suma protegida al global (reduccion local).
 * Es el patron "mapeo local + reduccion con mutex" de trabajador_hilo() en
 * SO2026B/concurrencia/HILOS_PROCESOS/main.c, aplicado a contar_frecuencias()
 * del Huffman secuencial del profesor sobre UN bloque. */
static int tarea_contar(Pipeline *p, uint32_t i, unsigned char *buf) {
    size_t n = tam_bloque_i(p, i);
    if (pleer_todo(p->fd_in, buf, n, (off_t)((uint64_t)i * p->tam_bloque)) < 0) {
        pipeline_abortar(p, 1, "error leyendo bloque %u: %s", i, strerror(errno));
        return -1;
    }
    uint32_t *h = p->hist[i];             /* solo este hilo escribe hist[i] */
    contar_frecuencias(buf, n, h);        /* PROFESOR: paso 1, mapeo local sin bloqueos */

    pthread_mutex_lock(&p->m);            /* paso 2: reduccion en seccion critica (256 sumas) */
    for (int s = 0; s < 256; s++) p->frec[s] += h[s];
    if (--p->pendientes == 0) pthread_cond_signal(&p->cond_fase);
    pthread_mutex_unlock(&p->m);

    progreso_avanzar(p->prog, 0, 40);
    return 0;
}

/* FASE 3: codifica el bloque con la tabla global (solo lectura). */
static int tarea_codificar(Pipeline *p, uint32_t i, unsigned char *buf) {
    size_t n = tam_bloque_i(p, i);
    if (pleer_todo(p->fd_in, buf, n, (off_t)((uint64_t)i * p->tam_bloque)) < 0) {
        pipeline_abortar(p, 1, "error leyendo bloque %u: %s", i, strerror(errno));
        return -1;
    }
    /* Tamano exacto de salida gracias al histograma local de la fase 1. */
    uint64_t bits = 0;
    for (int s = 0; s < 256; s++) bits += (uint64_t)p->hist[i][s] * p->largo[s];
    size_t bytes = (size_t)((bits + 7) / 8);
    unsigned char *out = malloc(bytes ? bytes : 1);
    if (!out) { pipeline_abortar(p, 1, "sin memoria para el bloque %u", i); return -1; }

    uint64_t acc = 0; int nbits = 0; size_t pos = 0;
    for (size_t k = 0; k < n; k++) {
        unsigned char c = buf[k];
        acc = (acc << p->largo[c]) | p->codigo[c];
        nbits += p->largo[c];
        while (nbits >= 8) { nbits -= 8; out[pos++] = (unsigned char)(acc >> nbits); }
    }
    if (nbits > 0) out[pos++] = (unsigned char)(acc << (8 - nbits));
    uint32_t crc = huf_crc32(0, buf, n);

    pthread_mutex_lock(&p->m);
    p->res[i].datos = out; p->res[i].tam = pos;
    p->res[i].tam_orig = (uint32_t)n; p->res[i].crc = crc;
    p->res[i].listo = 1;
    pthread_cond_signal(&p->cond_listo);  /* el unico que espera es el escritor */
    pthread_mutex_unlock(&p->m);
    return 0;
}

/* DESCOMPRESION: decodifica el bloque i y verifica su CRC32. */
static int tarea_decodificar(Pipeline *p, uint32_t i, unsigned char *buf_in) {
    size_t n_out = p->res[i].tam_orig;    /* fijados antes de arrancar los hilos */
    size_t n_in = (size_t)p->tam_comp[i];
    unsigned char *out = malloc(n_out ? n_out : 1);
    if (!out) { pipeline_abortar(p, 1, "sin memoria para el bloque %u", i); return -1; }
    if (pleer_todo(p->fd_in, buf_in, n_in, (off_t)p->off_comp[i]) < 0) {
        free(out);
        pipeline_abortar(p, 1, "error leyendo bloque comprimido %u: %s", i, strerror(errno));
        return -1;
    }
    /* Mismo recorrido que descomprimir_archivo() del profesor: bit 0 -> izq,
     * bit 1 -> der, al llegar a una hoja se emite el simbolo y se vuelve a la
     * raiz. Aqui sobre un bloque en memoria y verificando punteros nulos
     * (un archivo corrupto podria llevar a un hijo inexistente). */
    size_t k = 0;
    NodoHuffman *nodo = p->raiz;
    for (size_t b = 0; nodo && b < n_in && k < n_out; b++) {
        for (int bit = 7; bit >= 0 && k < n_out; bit--) {
            nodo = ((buf_in[b] >> bit) & 1) ? nodo->der : nodo->izq;
            if (!nodo) break;
            if (!nodo->izq && !nodo->der) { out[k++] = nodo->simbolo; nodo = p->raiz; }
        }
    }
    if (k != n_out) {
        free(out);
        pipeline_abortar(p, 1, "bloque %u corrupto (datos insuficientes o invalidos)", i);
        return -1;
    }
    if (huf_crc32(0, out, n_out) != p->res[i].crc) {
        free(out);
        pipeline_abortar(p, 1, "bloque %u corrupto (CRC32 no coincide)", i);
        return -1;
    }
    pthread_mutex_lock(&p->m);
    p->res[i].datos = out; p->res[i].tam = n_out; p->res[i].listo = 1;
    pthread_cond_signal(&p->cond_listo);
    pthread_mutex_unlock(&p->m);
    return 0;
}

/* Bucle de cada trabajador del pool. */
static void *hilo_trabajador(void *arg) {
    Pipeline *p = arg;
    /* Nombre visible en `ps -L` / `top -H` (sirve para ver el pool en la demo). */
    pthread_setname_np(pthread_self(), "huf-trabajador");
    size_t cap = p->tam_bloque;
    /* buffer de lectura propio de cada hilo: se reutiliza en todas sus tareas */
    unsigned char *buf = NULL;
    Tarea t;
    while (cola_sacar(&p->cola, &t) == 0) {
        if (!buf) {
            if (t.tipo == T_DECODIFICAR) {        /* el bloque comprimido puede ser mayor */
                for (uint32_t i = 0; i < p->n_bloques; i++) if (p->tam_comp[i] > cap) cap = (size_t)p->tam_comp[i];
            }
            buf = malloc(cap ? cap : 1);
            if (!buf) { pipeline_abortar(p, 1, "sin memoria en trabajador"); break; }
        }
        if (p->retardo_ms) dormir_ms(p->retardo_ms);  /* SOLO DEMO */
        int r = 0;
        switch (t.tipo) {
            case T_CONTAR:      r = tarea_contar(p, t.idx, buf); break;
            case T_CODIFICAR:   r = tarea_codificar(p, t.idx, buf); break;
            case T_DECODIFICAR: r = tarea_decodificar(p, t.idx, buf); break;
        }
        if (r < 0) break;
    }
    free(buf);
    return NULL;
}

/* Hilo escritor: escribe los bloques en orden 0..n-1. Si el bloque que toca
 * aun no esta listo, DUERME en cond_listo (no hay espera activa) aunque los
 * bloques posteriores ya esten terminados. */
static void *hilo_escritor(void *arg) {
    Pipeline *p = arg;
    pthread_setname_np(pthread_self(), "huf-escritor");
    int base = p->tam_comp ? 0 : 40, rango = p->tam_comp ? 99 : 59;
    for (uint32_t i = 0; i < p->n_bloques; i++) {
        pthread_mutex_lock(&p->m);
        while (!p->res[i].listo && !p->abortado) pthread_cond_wait(&p->cond_listo, &p->m);
        int abortado = p->abortado;
        unsigned char *datos = p->res[i].datos;
        size_t tam = p->res[i].tam;
        p->res[i].datos = NULL;               /* pasa a ser propiedad del escritor */
        pthread_mutex_unlock(&p->m);
        if (abortado) { free(datos); break; }

        int r = escribir_todo(p->fd_out, datos, tam);
        free(datos);
        if (r < 0) { pipeline_abortar(p, 1, "error escribiendo la salida: %s", strerror(errno)); break; }
        p->bytes_escritos += tam;
        progreso_avanzar(p->prog, base, rango);
        sem_post(&p->ventana);                /* libera un hueco de la ventana */
    }
    return NULL;
}

/* Crea un hilo con TODAS las senales bloqueadas: asi las senales (SIGINT,
 * SIGTERM...) solo las atiende el hilo principal del editor. */
static int crear_hilo(pthread_t *h, void *(*fn)(void *), void *arg) {
    sigset_t todas, previa;
    sigfillset(&todas);
    pthread_sigmask(SIG_BLOCK, &todas, &previa);
    int r = pthread_create(h, NULL, fn, arg);
    pthread_sigmask(SIG_SETMASK, &previa, NULL);
    return r;
}

static int hilos_por_defecto(const HufOpciones *op) {
    int n = (op && op->hilos > 0) ? op->hilos : (int)sysconf(_SC_NPROCESSORS_ONLN);
    if (n < 1) n = 1;
    if (n > HUF_HILOS_MAX) n = HUF_HILOS_MAX;
    return n;
}

static int pipeline_init(Pipeline *p, HufProgreso *prog, const HufOpciones *op) {
    memset(p, 0, sizeof(*p));
    p->dicc = calloc(1, sizeof(Diccionario));     /* ~67 KB: en el heap, no en la pila */
    if (!p->dicc) { errno = ENOMEM; return -1; }
    p->fd_in = p->fd_out = -1;
    p->prog = prog;
    p->n_hilos = hilos_por_defecto(op);
    p->tam_bloque = (op && op->tam_bloque) ? op->tam_bloque : HUF_BLOQUE_DEFECTO;
    if (p->tam_bloque > 0x7FFFFFFFu) p->tam_bloque = 0x7FFFFFFFu;
    p->retardo_ms = op ? op->retardo_ms : 0;
    cola_init(&p->cola);
    pthread_mutex_init(&p->m, NULL);
    pthread_cond_init(&p->cond_fase, NULL);
    pthread_cond_init(&p->cond_listo, NULL);
    /* ventana = 2 bloques por trabajador: suficiente para que nadie se
     * quede sin trabajo y acota la memoria a O(2*N*tam_bloque). */
    return sem_init(&p->ventana, 0, (unsigned)(2 * p->n_hilos));
}

static void pipeline_liberar(Pipeline *p) {
    if (p->res) for (uint32_t i = 0; i < p->n_bloques; i++) free(p->res[i].datos);
    free(p->res); free(p->hist); free(p->off_comp); free(p->tam_comp);
    liberar_arbol(p->raiz);              /* PROFESOR: liberacion post-orden */
    free(p->dicc);
    if (p->fd_in != -1) close(p->fd_in);
    if (p->fd_out != -1) close(p->fd_out);
    sem_destroy(&p->ventana);
    pthread_cond_destroy(&p->cond_listo);
    pthread_cond_destroy(&p->cond_fase);
    pthread_mutex_destroy(&p->m);
    cola_destruir(&p->cola);
}

/* Arranca el pool, despacha las tareas de 'tipo' de los bloques y espera.
 * Con 'con_escritor' tambien lanza el hilo escritor ordenado y usa la
 * ventana (semaforo) para no tener mas de 2N bloques en memoria. */
static void pipeline_fase_paralela(Pipeline *p, TipoTarea tipo, int con_escritor, pthread_t *esc, int *esc_ok) {
    if (con_escritor) {
        if (crear_hilo(esc, hilo_escritor, p) != 0) {
            pipeline_abortar(p, 1, "no se pudo crear el hilo escritor");
            return;
        }
        *esc_ok = 1;
    }
    for (uint32_t i = 0; i < p->n_bloques; i++) {
        if (con_escritor) {
            while (sem_wait(&p->ventana) == -1 && errno == EINTR) {}
        }
        if (pipeline_abortado(p)) break;
        Tarea t = { tipo, i };
        if (cola_meter(&p->cola, t) < 0) break;
    }
}

/* Crea los N trabajadores. Si alguno falla, sigue con los que se crearon. */
static int pipeline_crear_pool(Pipeline *p, pthread_t *hilos) {
    /* La tabla CRC se inicializa aqui, ANTES de crear los hilos: asi la
     * publicacion de la tabla queda ordenada por pthread_create (relacion
     * happens-before que cualquier detector entiende). pthread_once sigue
     * garantizando que se construya una sola vez. */
    huf_crc32(0, NULL, 0);
    int creados = 0;
    for (int k = 0; k < p->n_hilos; k++) {
        if (crear_hilo(&hilos[k], hilo_trabajador, p) != 0) break;
        creados++;
    }
    if (creados == 0) pipeline_abortar(p, 1, "no se pudo crear ningun hilo trabajador");
    return creados;
}

/* Cierra la cola, espera (join) a TODOS los hilos y retorna el codigo final. */
static int pipeline_terminar(Pipeline *p, pthread_t *hilos, int creados, pthread_t esc, int esc_ok,
                             char *err, size_t errlen) {
    cola_cerrar(&p->cola, 0);
    if (esc_ok) pthread_join(esc, NULL);
    for (int k = 0; k < creados; k++) pthread_join(hilos[k], NULL);
    pipeline_desregistrar(p);
    if (p->error) { if (err) snprintf(err, errlen, "%s", p->err); return HUF_ERROR; }
    if (p->abortado) { if (err) snprintf(err, errlen, "operacion cancelada"); return HUF_CANCELADO; }
    return HUF_OK;
}

static int mismo_archivo(const char *a, const char *b) {
    struct stat sa, sb;
    if (stat(a, &sa) == 0 && stat(b, &sb) == 0) return sa.st_dev == sb.st_dev && sa.st_ino == sb.st_ino;
    return strcmp(a, b) == 0;
}

/* Crea el temporal de salida en el mismo directorio que el destino. */
static int crear_temporal(const char *destino, char *tmp, size_t n) {
    snprintf(tmp, n, "%s.tmpXXXXXX", destino);
    int fd = mkstemp(tmp);
    if (fd >= 0) fchmod(fd, 0644);
    return fd;
}

static void fallar(char *err, size_t errlen, const char *fmt, ...) {
    if (!err) return;
    va_list ap; va_start(ap, fmt); vsnprintf(err, errlen, fmt, ap); va_end(ap);
}

/* ============================================================================
 * COMPRESION
 * ========================================================================== */
int huf_comprimir(const char *origen, const char *destino, const HufOpciones *op,
                  HufProgreso *prog_in, HufResultado *res, char *err, size_t errlen) {
    HufProgreso prog_local;
    HufProgreso *prog = prog_in;
    if (!prog) { huf_progreso_init(&prog_local, NULL, NULL); prog = &prog_local; }

    Pipeline P, *p = &P;
    char tmp[4096] = "";
    pthread_t hilos[HUF_HILOS_MAX], esc;
    int creados = 0, esc_ok = 0, rc = HUF_ERROR;

    if (pipeline_init(p, prog, op) != 0) { fallar(err, errlen, "no se pudo iniciar la operacion: %s", strerror(errno)); goto fin_sin_pipeline; }
    progreso_fase(prog, HUF_FASE_PREPARANDO, 0, 0);

    if (mismo_archivo(origen, destino)) { fallar(err, errlen, "origen y destino son el mismo archivo"); goto fin; }
    p->fd_in = open(origen, O_RDONLY | O_CLOEXEC);
    if (p->fd_in < 0) { fallar(err, errlen, "open(%s): %s", origen, strerror(errno)); goto fin; }
    struct stat st;
    if (fstat(p->fd_in, &st) < 0) { fallar(err, errlen, "fstat: %s", strerror(errno)); goto fin; }
    if (!S_ISREG(st.st_mode)) { fallar(err, errlen, "%s no es un archivo regular", origen); goto fin; }
    p->tam_original = (uint64_t)st.st_size;
    uint64_t nb = (p->tam_original + p->tam_bloque - 1) / p->tam_bloque;
    if (nb > 0xFFFFFFFFull) { fallar(err, errlen, "archivo demasiado grande para el tamano de bloque"); goto fin; }
    p->n_bloques = (uint32_t)nb;
    if ((uint32_t)p->n_hilos > p->n_bloques && p->n_bloques > 0) p->n_hilos = (int)p->n_bloques;

    p->hist = calloc(p->n_bloques ? p->n_bloques : 1, sizeof(*p->hist));
    p->res = calloc(p->n_bloques ? p->n_bloques : 1, sizeof(ResBloque));
    if (!p->hist || !p->res) { fallar(err, errlen, "sin memoria"); goto fin; }

    p->fd_out = crear_temporal(destino, tmp, sizeof(tmp));
    if (p->fd_out < 0) { fallar(err, errlen, "no se pudo crear %s: %s", tmp, strerror(errno)); tmp[0] = '\0'; goto fin; }

    if (pipeline_registrar(p) < 0) { fallar(err, errlen, "operacion cancelada"); rc = HUF_CANCELADO; goto fin; }

    creados = pipeline_crear_pool(p, hilos);

    /* ---- Fase 1: conteo de frecuencias en paralelo + barrera ---- */
    progreso_fase(prog, HUF_FASE_CONTEO, p->n_bloques, 0);
    pthread_mutex_lock(&p->m);
    p->pendientes = p->n_bloques;
    pthread_mutex_unlock(&p->m);
    pipeline_fase_paralela(p, T_CONTAR, 0, NULL, NULL);
    pthread_mutex_lock(&p->m);
    while (p->pendientes > 0 && !p->abortado) pthread_cond_wait(&p->cond_fase, &p->m);
    pthread_mutex_unlock(&p->m);

    /* ---- Fase 2: arbol global (solo el coordinador) ---- */
    if (!pipeline_abortado(p)) {
        progreso_fase(prog, HUF_FASE_ARBOL, 0, 40);
        char e[160];                          /* frec ya no cambia: barrera superada */
        if (construir_arbol_y_codigos(p->frec, &p->raiz, p->dicc, p->codigo, p->largo, e, sizeof(e)) < 0)
            pipeline_abortar(p, 1, "%s", e);
    }

    /* Cabecera + indice reservado (se rellena al final con pwrite). */
    if (!pipeline_abortado(p)) {
        unsigned char cab[TAM_CABECERA];
        memcpy(cab, MAGIA, 4);
        put_u32(cab + 4, VERSION);
        put_u64(cab + 8, p->tam_original);
        put_u32(cab + 16, (uint32_t)p->tam_bloque);
        put_u32(cab + 20, p->n_bloques);
        for (int s = 0; s < 256; s++) put_u64(cab + 24 + 8 * s, p->frec[s]);
        p->inicio_datos = TAM_CABECERA + (off_t)p->n_bloques * TAM_ENTRADA;
        if (escribir_todo(p->fd_out, cab, sizeof(cab)) < 0 ||
            lseek(p->fd_out, p->inicio_datos, SEEK_SET) < 0)
            pipeline_abortar(p, 1, "error escribiendo cabecera: %s", strerror(errno));
    }

    /* ---- Fase 3: codificacion en paralelo + escritor ordenado ---- */
    if (!pipeline_abortado(p)) {
        progreso_fase(prog, HUF_FASE_CODIFICACION, p->n_bloques, 40);
        pipeline_fase_paralela(p, T_CODIFICAR, 1, &esc, &esc_ok);
    }
    rc = pipeline_terminar(p, hilos, creados, esc, esc_ok, err, errlen);
    creados = 0; esc_ok = 0;

    /* ---- Indice, sincronizacion a disco y rename atomico ---- */
    if (rc == HUF_OK) {
        progreso_fase(prog, HUF_FASE_FINALIZANDO, 0, 99);
        size_t tam_idx = (size_t)p->n_bloques * TAM_ENTRADA;
        unsigned char *idx = malloc(tam_idx ? tam_idx : 1);
        if (!idx) { fallar(err, errlen, "sin memoria"); rc = HUF_ERROR; }
        else {
            for (uint32_t i = 0; i < p->n_bloques; i++) {
                put_u32(idx + i * TAM_ENTRADA, p->res[i].tam_orig);
                put_u32(idx + i * TAM_ENTRADA + 4, p->res[i].crc);
                put_u64(idx + i * TAM_ENTRADA + 8, p->res[i].tam);
            }
            if (pescribir_todo(p->fd_out, idx, tam_idx, TAM_CABECERA) < 0 || fsync(p->fd_out) < 0) {
                fallar(err, errlen, "error escribiendo indice: %s", strerror(errno)); rc = HUF_ERROR;
            }
            free(idx);
        }
        if (rc == HUF_OK) {
            if (close(p->fd_out) < 0) { fallar(err, errlen, "close: %s", strerror(errno)); rc = HUF_ERROR; }
            p->fd_out = -1;
        }
        if (rc == HUF_OK && rename(tmp, destino) < 0) {
            fallar(err, errlen, "rename: %s", strerror(errno)); rc = HUF_ERROR;
        }
        if (rc == HUF_OK) {
            tmp[0] = '\0';
            if (res) {
                res->tam_original = p->tam_original;
                res->tam_comprimido = (uint64_t)p->inicio_datos + p->bytes_escritos;
                res->bloques = p->n_bloques;
                res->hilos = p->n_hilos;
            }
            progreso_fase(prog, HUF_FASE_TERMINADA, p->n_bloques, 100);
        }
    }

fin:
    if (creados || esc_ok) {   /* solo si se salio por un error temprano */
        pipeline_abortar(p, 1, "abortado");
        pipeline_terminar(p, hilos, creados, esc, esc_ok, NULL, 0);
    }
    pipeline_desregistrar(p);
    if (p->fd_out != -1) { close(p->fd_out); p->fd_out = -1; }
    if (tmp[0]) unlink(tmp);              /* nunca deja salidas a medias */
    pipeline_liberar(p);
fin_sin_pipeline:
    if (prog == &prog_local) huf_progreso_destruir(&prog_local);
    return rc;
}

/* ============================================================================
 * DESCOMPRESION
 * ========================================================================== */
int huf_descomprimir(const char *origen, const char *destino, const HufOpciones *op,
                     HufProgreso *prog_in, HufResultado *res, char *err, size_t errlen) {
    HufProgreso prog_local;
    HufProgreso *prog = prog_in;
    if (!prog) { huf_progreso_init(&prog_local, NULL, NULL); prog = &prog_local; }

    Pipeline P, *p = &P;
    char tmp[4096] = "";
    pthread_t hilos[HUF_HILOS_MAX], esc;
    int creados = 0, esc_ok = 0, rc = HUF_ERROR;
    unsigned char *idx = NULL;

    if (pipeline_init(p, prog, op) != 0) { fallar(err, errlen, "no se pudo iniciar la operacion: %s", strerror(errno)); goto fin_sin_pipeline; }
    progreso_fase(prog, HUF_FASE_PREPARANDO, 0, 0);

    if (mismo_archivo(origen, destino)) { fallar(err, errlen, "origen y destino son el mismo archivo"); goto fin; }
    p->fd_in = open(origen, O_RDONLY | O_CLOEXEC);
    if (p->fd_in < 0) { fallar(err, errlen, "open(%s): %s", origen, strerror(errno)); goto fin; }
    struct stat st;
    if (fstat(p->fd_in, &st) < 0) { fallar(err, errlen, "fstat: %s", strerror(errno)); goto fin; }

    unsigned char cab[TAM_CABECERA];
    if ((uint64_t)st.st_size < TAM_CABECERA || pleer_todo(p->fd_in, cab, sizeof(cab), 0) < 0 ||
        memcmp(cab, MAGIA, 4) != 0) {
        fallar(err, errlen, "%s no es un archivo .huf valido", origen); goto fin;
    }
    if (get_u32(cab + 4) != VERSION) { fallar(err, errlen, "version de formato no soportada"); goto fin; }
    p->tam_original = get_u64(cab + 8);
    p->tam_bloque = get_u32(cab + 16);
    p->n_bloques = get_u32(cab + 20);
    uint64_t suma_frec = 0;
    for (int s = 0; s < 256; s++) { p->frec[s] = get_u64(cab + 24 + 8 * s); suma_frec += p->frec[s]; }
    if (p->tam_bloque == 0 || suma_frec != p->tam_original ||
        p->n_bloques != (p->tam_original + p->tam_bloque - 1) / p->tam_bloque) {
        fallar(err, errlen, "cabecera inconsistente (archivo corrupto)"); goto fin;
    }
    if ((uint32_t)p->n_hilos > p->n_bloques && p->n_bloques > 0) p->n_hilos = (int)p->n_bloques;
    /* el semaforo se creo con 2*hilos_por_defecto; si bajamos hilos, la ventana sigue siendo valida */

    size_t tam_idx = (size_t)p->n_bloques * TAM_ENTRADA;
    p->inicio_datos = TAM_CABECERA + (off_t)tam_idx;
    if ((uint64_t)st.st_size < (uint64_t)p->inicio_datos) { fallar(err, errlen, "indice truncado (archivo corrupto)"); goto fin; }
    idx = malloc(tam_idx ? tam_idx : 1);
    p->res = calloc(p->n_bloques ? p->n_bloques : 1, sizeof(ResBloque));
    p->off_comp = calloc(p->n_bloques ? p->n_bloques : 1, sizeof(uint64_t));
    p->tam_comp = calloc(p->n_bloques ? p->n_bloques : 1, sizeof(uint64_t));
    if (!idx || !p->res || !p->off_comp || !p->tam_comp) { fallar(err, errlen, "sin memoria"); goto fin; }
    if (pleer_todo(p->fd_in, idx, tam_idx, TAM_CABECERA) < 0) { fallar(err, errlen, "error leyendo indice"); goto fin; }

    uint64_t off = (uint64_t)p->inicio_datos;
    for (uint32_t i = 0; i < p->n_bloques; i++) {
        p->res[i].tam_orig = get_u32(idx + i * TAM_ENTRADA);
        p->res[i].crc = get_u32(idx + i * TAM_ENTRADA + 4);
        p->tam_comp[i] = get_u64(idx + i * TAM_ENTRADA + 8);
        p->off_comp[i] = off;
        off += p->tam_comp[i];
        uint64_t esperado = (i + 1 < p->n_bloques) ? p->tam_bloque : p->tam_original - (uint64_t)i * p->tam_bloque;
        if (p->res[i].tam_orig != esperado || p->tam_comp[i] > (uint64_t)p->tam_bloque * MAX_LARGO_CODIGO / 8 + 8) {
            fallar(err, errlen, "indice inconsistente en el bloque %u (archivo corrupto)", i); goto fin;
        }
    }
    if (off != (uint64_t)st.st_size) { fallar(err, errlen, "tamano de datos inconsistente (archivo corrupto/truncado)"); goto fin; }

    {
        char e[160];
        if (construir_arbol_y_codigos(p->frec, &p->raiz, p->dicc, p->codigo, p->largo, e, sizeof(e)) < 0) {
            fallar(err, errlen, "%s", e); goto fin;
        }
    }

    p->fd_out = crear_temporal(destino, tmp, sizeof(tmp));
    if (p->fd_out < 0) { fallar(err, errlen, "no se pudo crear %s: %s", tmp, strerror(errno)); tmp[0] = '\0'; goto fin; }

    if (pipeline_registrar(p) < 0) { fallar(err, errlen, "operacion cancelada"); rc = HUF_CANCELADO; goto fin; }

    creados = pipeline_crear_pool(p, hilos);
    progreso_fase(prog, HUF_FASE_DECODIFICACION, p->n_bloques, 0);
    pipeline_fase_paralela(p, T_DECODIFICAR, 1, &esc, &esc_ok);
    rc = pipeline_terminar(p, hilos, creados, esc, esc_ok, err, errlen);
    creados = 0; esc_ok = 0;

    if (rc == HUF_OK) {
        progreso_fase(prog, HUF_FASE_FINALIZANDO, 0, 99);
        if (fsync(p->fd_out) < 0 || close(p->fd_out) < 0) { fallar(err, errlen, "error cerrando la salida: %s", strerror(errno)); rc = HUF_ERROR; }
        p->fd_out = -1;
        if (rc == HUF_OK && rename(tmp, destino) < 0) { fallar(err, errlen, "rename: %s", strerror(errno)); rc = HUF_ERROR; }
        if (rc == HUF_OK) {
            tmp[0] = '\0';
            if (res) {
                res->tam_original = p->tam_original;
                res->tam_comprimido = (uint64_t)st.st_size;
                res->bloques = p->n_bloques;
                res->hilos = p->n_hilos;
            }
            progreso_fase(prog, HUF_FASE_TERMINADA, p->n_bloques, 100);
        }
    }

fin:
    if (creados || esc_ok) {
        pipeline_abortar(p, 1, "abortado");
        pipeline_terminar(p, hilos, creados, esc, esc_ok, NULL, 0);
    }
    pipeline_desregistrar(p);
    free(idx);
    if (p->fd_out != -1) { close(p->fd_out); p->fd_out = -1; }
    if (tmp[0]) unlink(tmp);
    pipeline_liberar(p);
fin_sin_pipeline:
    if (prog == &prog_local) huf_progreso_destruir(&prog_local);
    return rc;
}
