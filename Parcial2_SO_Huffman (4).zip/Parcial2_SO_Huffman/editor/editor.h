#ifndef EDITOR_H
#define EDITOR_H

#include "estructura.h"

// Colores ANSI del tema visual del editor.
#define TEMA_FONDO         "\x1b[49m"   // Fondo de la terminal (49 = Defecto)
#define TEMA_TEXTO         "\x1b[39m"   // Color del texto principal (39 = Defecto)
#define TEMA_BARRA_ESTADO  "\x1b[7m"    // Barra inferior invertida
#define TEMA_LINEA_VACIA   "~"          // Símbolo para las líneas vacías al final
#define TEMA_RESTAURAR     "\x1b[0m"    // Restablece todos los formatos

// Estado global de una sesion de edicion (cursor, archivo abierto, etc.).
typedef struct {
    EstructuraTexto *estructura;    // Estructura de datos (Modelo)
    int cursorX;              // Posición lógica del cursor (Columnas)
    int cursorY;              // Posición lógica del cursor (Filas)
    int filasPantalla;        // Límite visual de la ventana
    int columnasPantalla;     // Límite visual de la ventana
    NodoLinea *lineaActual;   // Referencia rápida al nodo donde estamos escribiendo
    char *nombreArchivo;      // Ruta del archivo abierto
    int mostrarAyuda;         // Bandera booleana de UI (modal de ayuda, Ctrl+H)
    int desplazamientoFila;   // Desplazamiento (Scroll) vertical

    int fdArchivo; // descriptor persistente del modo de ordenes (':'); -1 si no hay archivo abierto

    // PARCIAL 2: mensaje corto que se muestra en la barra de estado (p. ej.
    // "guardado rechazado: archivo en compresion"). Se borra con la siguiente tecla.
    char mensaje[256];
} EstadoEditor;

// Funciones del ciclo de vida y renderizado
void editor_inicializar(EstadoEditor *e, const char* nombreArchivo);
void editor_liberar(EstadoEditor *e);
void editor_refrescar_pantalla(EstadoEditor *e);
void editor_procesar_tecla(EstadoEditor *e);

// Funciones expuestas del UI para el procesamiento de comandos
void editor_pantalla_limpiar(void);

// Muestra una pantalla de bienvenida al arrancar
void editor_pantalla_bienvenida(EstadoEditor *e);

// Mueve el cursor logico al final del documento (se usa tras recargar la
// estructura desde disco, por ejemplo despues de 'a', 'd', 'i', 'x').
void editor_reposicionar_cursor_final(EstadoEditor *e);

// PARCIAL 2: reabre el descriptor del archivo y recarga la vista desde disco
// (se usa cuando una descompresion en segundo plano reemplazo el archivo).
void editor_recargar_desde_disco(EstadoEditor *e);

// PARCIAL 2: cancela/une la tarea en segundo plano, restaura la terminal,
// libera memoria y termina el proceso (Ctrl+Q, 'q', senales, EOF).
void editor_salir_limpio(EstadoEditor *e);

// PARCIAL 2: intenta tomar (sin bloquear) el candado del archivo del editor
// para leerlo (escribir=0) o modificarlo (escribir=1). Si una descompresion
// acaba de reemplazar el archivo, lo recarga ANTES de devolver el control.
// Retorna 0 si se obtuvo (liberar con tarea_soltar_archivo()); -1 si el
// archivo esta ocupado, dejando el motivo en e->mensaje.
int editor_tomar_archivo(EstadoEditor *e, int escribir);

#endif
